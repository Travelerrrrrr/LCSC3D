# LCSC3D issue #13 — v9_pad0 variant / 变体样例

This package contains **PcbLib files only**. The changes below apply to footprint libraries. There is no v9_pad0 variant of the schematic libraries; use the SchLib files in `baseline.zip` when you need to test schematic libraries.

本压缩包**只包含 PcbLib**。下列改动只针对封装库。原理图库没有对应的 v9_pad0 变体；测试 SchLib 时请使用 `baseline.zip` 中的文件。

The libraries started as **LCSC3D v2.5.0** exports (git commit `9d6040020d71708239cd3d8a71922958aff5866c`) for parts C2040 and C2765186, then were **post-processed** (the product source code was not modified):

这些库最初由 **LCSC3D v2.5.0**（git 提交 `9d6040020d71708239cd3d8a71922958aff5866c`）为 C2040 与 C2765186 导出，随后做了**后处理**（未修改产品源码）：

1. The PcbLib `Library/Data` board-parameter block was replaced with the official template taken from a public Altium-saved `footprints.PcbLib` (includes `V9_MASTERSTACK_*` and `V9_STACK_LAYER*`, with `VERSION=3.00`). The LCSC3D footprint name table was kept.
2. Every pad Block 5 (size/shape stack) was set to **0 bytes**.

1. 用公开的 Altium 原生存档 `footprints.PcbLib` 中的官方板参数块替换 `Library/Data`（含 `V9_MASTERSTACK_*`、`V9_STACK_LAYER*`，`VERSION=3.00`），并保留 LCSC3D 的封装名表。
2. 将所有焊盘 Block 5（尺寸/形状堆叠）改为 **0 字节**。

3D/STEP models are not embedded. These variant PcbLib files have been confirmed to **open in Altium Designer 26 (build 26.7.1.11)**. A successful open in AD26 does **not** rule out a hang or error in AD24.10.1.

未内嵌 3D/STEP 模型。这些变体 PcbLib 已在 **Altium Designer 26（版本 26.7.1.11）** 上确认可以打开。AD26 能打开**并不能**排除 AD24.10.1 仍会卡死或报错。

To keep the archive free of machine-specific paths, two parameter values inherited from the public official `footprints.PcbLib` template were reduced to basenames before packing: `FILENAME` and `2DCONFIGFULLFILENAME`. The V9 stack keys and the 0-byte pad Block 5 were not changed. The AD26 26.7.1.11 open test used the same variant before this path redaction.

为避免压缩包含有第三方官方样本里的本机路径，打包前将继承自公开 `footprints.PcbLib` 模板的 `FILENAME` 与 `2DCONFIGFULLFILENAME` 两个参数值改成了不带目录的文件名。V9 层叠键和焊盘 Block 5 为 0 字节的改动未变。AD26 26.7.1.11 的打开验证使用的是同一变体在路径脱敏之前的文件。

## Files / 文件

| File | Description |
| --- | --- |
| `C2040.PcbLib` | C2040 footprint library, v9_pad0 variant / C2040 封装库，v9_pad0 变体 |
| `C2765186.PcbLib` | C2765186 footprint library, v9_pad0 variant / C2765186 封装库，v9_pad0 变体 |

## SHA-256

```
49d61e9be941f3b3c8bbe1970228bf23004cd3ef1018033ec658e5f94d391fc4  C2040.PcbLib
e4029413120c601992de248f4f324de7931a1663525ba7f70be8a42b2c33d6b9  C2765186.PcbLib
```
