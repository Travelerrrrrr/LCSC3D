# LCSC3D issue #13 — baseline samples / 基线样例

These files were exported with **LCSC3D v2.5.0** (git commit `9d6040020d71708239cd3d8a71922958aff5866c`) from the project's official fixture data for parts C2040 and C2765186. They are **unmodified** exporter output: 3D/STEP models are not embedded, the PcbLib board-parameter block does not include official V9 stack keys, and pad Block 5 is 596 bytes as written by v2.5.0.

这些文件由 **LCSC3D v2.5.0**（git 提交 `9d6040020d71708239cd3d8a71922958aff5866c`）根据项目官方夹具数据导出，元件为 C2040 与 C2765186。它们是**未经后处理**的导出结果：未内嵌 3D/STEP 模型，PcbLib 板参数块不含官方 V9 层叠键，焊盘 Block 5 为 v2.5.0 写出的 596 字节。

They have been confirmed to **open in Altium Designer 26 (build 26.7.1.11)**. A successful open in AD26 does **not** rule out a hang or error in AD24.10.1, which is the version described in issue #13.

已在 **Altium Designer 26（版本 26.7.1.11）** 上确认可以打开。AD26 能打开**并不能**排除 AD24.10.1（议题 #13 所述版本）仍会卡死或报错。

## Files / 文件

| File | Description |
| --- | --- |
| `C2040.SchLib` | Schematic library for part C2040 (RP2040) / C2040（RP2040）的原理图库 |
| `C2040.PcbLib` | Footprint library for part C2040 / C2040 的封装库 |
| `C2765186.SchLib` | Schematic library for part C2765186 (USB Type-C) / C2765186（USB Type-C）的原理图库 |
| `C2765186.PcbLib` | Footprint library for part C2765186 / C2765186 的封装库 |

## SHA-256

```
f8a3dc888ea10fcc8f44c4aa936946bfbdf868d122dc845d52b1cb1b41b0f995  C2040.SchLib
8b0d5cb3e83cce577182f6830d6fe872eb62cd5ecc3360c7f0b967514ea87792  C2040.PcbLib
51c651f07f93b2290e2f9db696c39bfd4988b6af8e9116dd950fc079e806b740  C2765186.SchLib
5d0bcb7dcd35d085c15f86bf78323d8be27533d3dda06501a43ca7c209bef306  C2765186.PcbLib
```
